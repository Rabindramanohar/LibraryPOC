export class Book {
   /*  name: string;
    key: string;
    ebook_count: string; */
}